﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using System.ComponentModel;

namespace BAARS_4_Tester
{

    /// <summary>
    /// Interaction logic for TesterAnswers.xaml
    /// </summary>
    public partial class TesterAnswers : Window
    {

        private bool adultAnswersEncrypted = true, childAnswersEncrypted = true, adultResultsEncrypted = true, 
            childResultsEncrypted = true;
        private struct AnswersTable
        {
            public AnswersTable(string answer, string question)
            {
                Quesetion = question;
                Answers = answer;
            }

            public string Quesetion { get; set; }
            public string Answers { get; set; }
        }

        Tester t;
        //private AnswersTable[] tableData = new AnswersTable[25];
        
        public TesterAnswers(Tester t)
        {
            this.t = t;
            InitializeComponent();
            //getAnswers(K.adultAnswers);
            nameLabel.Text = t.firstName + " " + t.middleName + " " + t.lastName;
            //Closing += TesterAnswers.OnWindowClosing();
            //adultAnswersEncrypted = containsString(t.path + K.adultAnswers, t.lastName);
            //adultResultsEncrypted = containsString(t.path + K.adultResults, t.lastName);
            //childResultsEncrypted = containsString(t.path + K.adultResults, t.lastName);
            //childAnswersEncrypted = containsString(t.path + K.adultResults, t.lastName);
            //Closing += OnWindowClosing;
            
        }

        private void OnWindowClosing(object sender, CancelEventArgs e)
        {
            if (!adultAnswersEncrypted)
                Encrypter.EncryptFile(t.path + K.adultAnswers, K.pubKey());
            if (!adultResultsEncrypted)
                Encrypter.EncryptFile(t.path + K.adultResults, K.pubKey());
            if (!childAnswersEncrypted)
                Encrypter.EncryptFile(t.path + K.childAnswers, K.pubKey());
            if (!childResultsEncrypted)
                Encrypter.EncryptFile(t.path + K.childResults, K.pubKey());
        }

        private void showAdult_Click(object sender, RoutedEventArgs e)
        {
            if (K.pubKey() != null)
            {
                getAnswers(K.adultAnswers);
                resultsLabel.Content = loadAdultResults(t.path + K.adultResults);
                adultAnswersEncrypted = false;
                adultResultsEncrypted = false;
            } else
            {
                
                Table.ItemsSource = null;
                resultsLabel.Content = "";
                MessageBox.Show("This is sensitive information and you should not be viewing it without proper authorization");
            }
        }

        private void showChild_Click(object sender, RoutedEventArgs e)
        {
            if (K.pubKey() != null)
            {
                getAnswers(K.childAnswers);
                resultsLabel.Content = loadChildResults(t.path + K.childResults);
                childAnswersEncrypted = false;
                childResultsEncrypted = false;
            } else
            {
                Table.ItemsSource = null;
                resultsLabel.Content = "";
                MessageBox.Show("This is sensitive information and you should not be viewing it without proper authorization");
            }
        }

        private void showOther_Click(object sender, RoutedEventArgs e)
        {

        }

        private void getAnswers(string answersPath)
        {
            //if (answersPath.Equals(K.adultAnswers) && adultAnswersEncrypted)
                //Encrypter.DecryptFile(t.path + answersPath, K.key);

            //if (answersPath.Equals(K.childAnswers) && childAnswersEncrypted)
                //Encrypter.DecryptFile(t.path + answersPath, K.key);

            List<AnswersTable> answersList = new List<AnswersTable>();

            if (File.Exists(t.path + answersPath))
            {
                //MessageBox.Show(" ");
                //string[] answers = File.ReadAllLines(t.path + answersPath);
                string[] answers = Encrypter.DecryptFile(t.path + answersPath, K.pubKey());
                //tableData = new AnswersTable[27];

                for (int i = 0; i < answers.Length - 5; i++) // Starts at 4 to skip beginning of line
                {
                    //tableData[i].Answers = answers[i].Substring(answers[i].IndexOf(".") + 1).ToString();
                    //tableData[i].Quesetions = "LOLWHAT";

                    string question = answers[i + 5].Substring(answers[i + 5].IndexOf(" ") + 1).ToString();
                    string answer = answers[i + 5].Substring(0, answers[i + 5].IndexOf(".")).ToString();


                    answersList.Add(new AnswersTable(question, answer)); //This shouldn't work but it does... why?

                    //MessageBox.Show(tableData[i].Answers);
                }

                Table.IsReadOnly = true;
                Table.ItemsSource = answersList;

            }
        }

        private string loadAdultResults(string filePath)
        {
            string results = "Adult results:\n\n";

            if (adultResultsEncrypted)
                Encrypter.DecryptFile(filePath, K.pubKey());


            if (File.Exists(filePath))
            {
                //string[] lines = File.ReadAllLines(filePath);
                string[] lines = Encrypter.DecryptFile(filePath, K.pubKey());

                for (int i = 5; i < 14; i++)
                {
                    results += lines[i] + "\n";
                }

                results += "\n";

                for (int j = 17; j < lines.Length; j++)
                {
                    results += lines[j] + "\n";
                }
            }

            return results;
        }

        private string loadChildResults(string filePath)
        {

            string results = "Child results: \n\n";

            if (File.Exists(filePath))
            {
                //string[] lines = File.ReadAllLines(filePath);
                string[] lines = Encrypter.DecryptFile(filePath, K.pubKey());

                for (int i = 5; i < 9; i++)
                {
                    results += lines[i] + "\n";
                }

                results += "\n";
                results += lines[9] + "\n";
                results += lines[10] + "\n";

            }

            return results;
        }

        private bool containsString(string filepath, string str)
        {
            foreach (var line in File.ReadAllLines(filepath))
            {
                if (line.Contains(str))
                    return true;
            }

            return false;
        }

    }
}
