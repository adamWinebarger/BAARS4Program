﻿//using BAARS_4_Tester;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System;

namespace UnitTestcases
{
    [TestClass]
    public class ScoreBAARSTesting
    {
        [TestMethod]
        public void TotalScoreTesting()
        {
            
            ScoreBAARS scoreBAARS = new ScoreBAARS();

            var result_1 = scoreBAARS.TotalScore(2, 7);
            Assert.AreEqual(6, result_1);

            var result_2 = scoreBAARS.TotalScore(-1, 2);
            Assert.AreEqual(3, result_2);

            var result_3 = scoreBAARS.TotalScore(0, 0);
            Assert.AreEqual(0, result_3);
        }

        [TestMethod]
        public void SymptomCountTesting()
        {

            //Arrange
            var scoreBAARS = new ScoreBAARS();
            scoreBAARS.TotalScore(2, 7);

            var result_1 = scoreBAARS.SymptomCount(1, 2);
            Assert.AreEqual(1, result_1);

            scoreBAARS.ScoreBAARS(new int[] {1}); //Setting answers to 1

            var result_2 = scoreBAARS.SymptomCount(1, 20);
            Assert.AreEqual(0, result_2);

            scoreBAARS.ScoreBAARS();
            var result_3 = scoreBAARS.SymptomCount(2, 0);
            Assert.AreEqual(0, result_3);
        }


        [TestMethod]
        public void ScoreBAARSAdultTesting()
        {

            //Arrange
            var scoreBAARSAdult = new ScoreBAARSAdult();
            scoreBAARSAdult.TotalScore(2, 7);

            var result_1 = scoreBAARSAdult.GetSymptomTotal(1);
            Assert.AreEqual(section1Symptoms, result_1);


            var result_2 = scoreBAARSAdult.GetSymptomTotal(5);
            Assert.AreEqual(-999, result_2);

            
            var result_3 = scoreBAARSAdult.getOther("total1thru3");
            Assert.AreEqual(sumTotal1thru3, result_3);

            var result_4 = scoreBAARSAdult.getOther("total1");
            Assert.AreEqual(-999, result_4);

            var result_5 = scoreBAARSAdult.GetSectionTotal(1);
            Assert.AreEqual(section1Total, result_5);

            var result_6 = scoreBAARSAdult.GetSectionTotal(0);
            Assert.AreEqual(-999, result_6);

        }


        [TestMethod]
        public void ScoreBAARSYouthTesting()
        {

            //Arrange
            var scoreBAARSYouth = new ScoreBAARSYouth();
            scoreBAARSAdult.TotalScore(2, 7);

            var result_1 = scoreBAARSYouth.GetValue("total1");
            Assert.AreEqual(total1, result_1) ;

            var result_2 = scoreBAARSYouth.GetValue("sumTotal");
            Assert.AreEqual(sumTotals, result_2);

            
            var result_3 = scoreBAARSYouth.GetValue("tot");
            Assert.AreEqual(-999, result_3);


        }


    }
}
